package com.example.project1442.Helper;

public interface ChangeNumberItemsListener {
    void change();
}
